package com.example.shipperapplication.model;

public class OrderId {
    private int orderid;

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }
}
